using System;
using System.Collections.Generic;

namespace Pyrate {
    public enum Shot { Harbor, Departure, OpenSea, Battle, Return }

    public sealed class VoyageFrame {
        public Shot Shot { get; private set; }
        public double Age { get; private set; }
        public double Duration { get; private set; }
        public double WaitRemaining { get; private set; }
        public int Port { get; private set; }
        public string Headline { get; private set; }
        public string Detail { get; private set; }
        public string Mode { get; private set; }
        public double Progress { get { return Duration <= 0 ? 0 : Math.Max(0, Math.Min(1, Age / Duration)); } }

        internal VoyageFrame(Shot shot, double age, double duration, int port, string headline, string detail, string mode, double waitRemaining) {
            Shot=shot; Age=age; Duration=duration; Port=port; Headline=headline; Detail=detail; Mode=mode; WaitRemaining=waitRemaining;
        }
    }

    public sealed class VoyageTimeline {
        private sealed class Encounter {
            public int Ordinal;
            public string Mode, Title, Detail;
            public bool Resolved, Started;
            public double WaitUntil;
        }

        private readonly Queue<Encounter> ports = new Queue<Encounter>();
        private Encounter current, reported;
        private Shot shot = Shot.Harbor;
        private double begin, duration;
        private double holdUntil;
        private string waitDetail, result;
        private bool running;
        private bool hasReturned;
        private int serial;
        private int displayPort;
        private string displayMode;
        private string displayDetail;

        public bool Running { get { return running; } }
        public bool ReturnPending { get { return !running && shot != Shot.Harbor; } }
        public bool NeedsClock { get { return running || shot != Shot.Harbor; } }
        public int PortsObserved { get { return serial; } }
        public int Backlog { get { return ports.Count; } }

        public void Start(double now) {
            if (running) return;
            bool continueAtSea = shot != Shot.Harbor && shot != Shot.Return;
            bool reuseReturn = shot == Shot.Return;
            if (!continueAtSea) {
                ports.Clear();
                serial=0; displayPort=0; current=null; reported=null;
                displayMode=""; displayDetail="";
            }
            running=true; hasReturned=false; result=""; holdUntil=0; waitDetail=null;
            if (!continueAtSea) Cut(reuseReturn ? Shot.OpenSea : Shot.Departure, now, reuseReturn ? 1.0 : 1.65);
        }

        public void EnterPort(string mode, string title, string listPosition) {
            if (!running) return;
            if (reported != null && !reported.Resolved) reported.Resolved=true;
            var next = new Encounter();
            next.Ordinal = ++serial;
            next.Mode = mode == "Captions" ? "Transcript" : mode;
            next.Title = String.IsNullOrWhiteSpace(title) ? "Unnamed cargo" : title.Trim();
            if (reported == null && holdUntil > 0) next.WaitUntil=holdUntil;
            next.Detail = (String.IsNullOrWhiteSpace(listPosition) ? "" : listPosition.Trim() + "  /  ") + next.Title;
            ports.Enqueue(next);
            reported=next;
        }

        public void SignalActivity() {
            holdUntil=0;
            if (reported != null) {
                reported.Started=true;
                reported.WaitUntil=0;
            }
        }

        public void ResolvePort() {
            SignalActivity();
            if (reported != null) {
                reported.Resolved=true;
                reported=null;
            }
        }

        public void BeginWait(double now, double seconds, string detail) {
            if (!running || seconds < 0.15) return;
            double until=now+Math.Min(seconds,3600);
            SetHold(until, detail);
            if (reported != null && !reported.Resolved) reported.WaitUntil=until;
            if (current != null && current == reported && shot == Shot.Battle) Cut(Shot.OpenSea,now,0.35);
        }

        private void SetHold(double until, string detail) {
            holdUntil=until;
            waitDetail=String.IsNullOrWhiteSpace(detail) ? "Waiting on the source" : detail.Trim();
        }

        public void Finish(double now, string status, bool moreQueued) {
            if (!running) return;
            ResolvePort();
            if (moreQueued) return;
            running=false; result=status;
            if (String.Equals(status,"Cancelled",StringComparison.OrdinalIgnoreCase)) {
                ports.Clear(); current=null; reported=null;
                Cut(Shot.Return, now, 1.9);
            }
        }

        private void Cut(Shot next, double now, double length) {
            shot=next; begin=now; duration=length;
        }

        private double Crossing(bool motion) {
            if (!motion) return 0;
            return ports.Count >= 12 ? .28 : ports.Count >= 4 ? .46 : .78;
        }

        private double BattleLength(bool motion) {
            if (!motion) return 0;
            return ports.Count >= 12 ? .86 : ports.Count >= 4 ? 1.06 : 1.46;
        }

        private bool Transition(double now, bool motion) {
            double age=now-begin;
            switch (shot) {
                case Shot.Harbor:
                    return false;
                case Shot.Departure:
                    if (motion && age < duration) return false;
                    Cut(Shot.OpenSea,now,motion ? .6 : 0);
                    return true;
                case Shot.OpenSea:
                    if (motion && age < duration) return false;
                    if (current == null && ports.Count > 0) current=ports.Dequeue();
                    if (current != null) {
                        if (!current.Resolved && (now < current.WaitUntil || !current.Started)) return false;
                        displayPort=current.Ordinal; displayMode=current.Mode; displayDetail=current.Detail;
                        Cut(Shot.Battle,now,BattleLength(motion));
                        return true;
                    }
                    if (!running) { Cut(Shot.Return,now,motion ? 2.65 : 0); return true; }
                    return false;
                case Shot.Battle:
                    if (current == null) { Cut(Shot.OpenSea,now,Crossing(motion)); return true; }
                    if ((!current.Resolved && now < current.WaitUntil) ||
                        (current.Resolved && (!motion || age >= duration))) {
                        if (current.Resolved) current=null;
                        Cut(Shot.OpenSea,now,(ports.Count > 0 || running || current != null) ? Crossing(motion) : 0);
                        return true;
                    }
                    return false;
                case Shot.Return:
                    if (motion && age < duration) return false;
                    hasReturned=true;
                    Cut(Shot.Harbor,now,0);
                    return true;
            }
            return false;
        }

        public VoyageFrame Tick(double now, bool motion) {
            // A static deck never makes a download wait for the visual timeline.
            for (int i=0; i<2048 && Transition(now,motion); i++) { }
            double age=Math.Max(0,now-begin);
            string headline, detail, mode=displayMode ?? "";
            int port=displayPort;
            double waiting=0;
            switch (shot) {
                case Shot.Departure:
                    headline="Setting sail";
                    detail="Leaving the moonlit lagoon";
                    break;
                case Shot.OpenSea:
                    var target=current ?? (ports.Count > 0 ? ports.Peek() : null);
                    if (!running) waiting=0;
                    else if (target != null && !target.Resolved && target.WaitUntil > now) waiting=target.WaitUntil-now;
                    else if (target == null && holdUntil > now) waiting=holdUntil-now;
                    headline=waiting > 0 ? "Riding out the wait" :
                        displayPort > 0 || (target != null && target.Ordinal > 1) ? "On to the next port" : "Starting our voyage";
                    if (waiting > 0) detail=(waitDetail ?? "Waiting on the source") + "  /  " + Math.Ceiling(waiting) + "s";
                    else if (target != null) detail=target.Detail;
                    else detail=running ? "Open water • Charting the next bearing" : "Leaving the last port";
                    if (target != null) { port=target.Ordinal; mode=target.Mode; }
                    break;
                case Shot.Battle:
                    headline="Plundering in progress";
                    detail=displayDetail ?? "";
                    break;
                case Shot.Return:
                    headline=result == "Cancelled" ? "Turning for harbor" : "Making for harbor";
                    detail=result == "Complete" ? "Last haul secured" : result == "Partial" ? "Returning with the cargo recovered" :
                        result == "Cancelled" ? "Finished cargo is safe" : "The voyage has ended";
                    break;
                default:
                    headline=hasReturned ? "Back at anchor" : "The moonlit lagoon";
                    detail=hasReturned ? "The crew is home" : "The crew awaits your next haul";
                    port=0; mode="";
                    break;
            }
            return new VoyageFrame(shot,age,duration,port,headline,detail,mode,waiting);
        }
    }
}
